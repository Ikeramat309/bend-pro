import '@/global.css';

import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from 'expo-router';
import { useColorScheme } from 'react-native';

import { AnimatedSplashOverlay } from '@/components/animated-icon';
import { SettingsProvider } from '@/core/settings';

export default function RootLayout() {
  const colorScheme = useColorScheme();

  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <SettingsProvider>
        <AnimatedSplashOverlay />
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="bends" />
          <Stack.Screen name="settings" />
          <Stack.Screen name="bender-database" />
          <Stack.Screen name="guide" />
          <Stack.Screen name="offset" />
          <Stack.Screen name="stub90" />
          <Stack.Screen name="saddle3" />
          <Stack.Screen name="saddle4" />
          <Stack.Screen name="segment" />
          <Stack.Screen name="rolling" />
        </Stack>
      </SettingsProvider>
    </ThemeProvider>
  );
}
