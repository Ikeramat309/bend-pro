import { useRouter } from 'expo-router';
import { useMemo, useState } from 'react';

import { patchCalculatorSetup, useCalculatorSetup } from '@/core/settings';
import { DEFAULT_CONDUIT_TYPE } from '@/data/conduit';
import { getBenderProfile } from '@/data/benders';
import { Routes, guideRoute } from '@/navigation';
import { LengthInputSheet, OptionChipGroup, Sheet } from '@/shared/ui';
import {
  BendCalculatorLayout,
  EditSetupSheet,
  OptionalInputSummary,
  type SetupValues,
} from '@/shared/workspace';
import { getRoundingLabel } from '@/utils/rounding';
import { getLengthUnitLabel, getLengthInputMode, getUnitSystemLabel } from '@/utils/units';
import { parseLengthInput } from '@/utils/parseLengthInput';

import { calculateSaddle4 } from '../engine/saddle4.engine';
import { getSaddle4AngleData, SADDLE4_ANGLE_DATA } from '../engine/saddle4AngleData';
import type { Saddle4Angle } from '../engine/saddle4.types';
import { SADDLE4_CONFIG } from '../saddle4.config';
import { saddle4Copy } from '../saddle4.copy';
import { Saddle4Diagram } from './Saddle4Diagram';

const ANGLE_LABELS = SADDLE4_CONFIG.validAngles.map((angle) => SADDLE4_ANGLE_DATA[angle].label);

export default function Saddle4Screen() {
  const router = useRouter();

  const [obstructionHeightText, setObstructionHeightText] = useState('');
  const [saddleWidthText, setSaddleWidthText] = useState('');
  const [showSaddleWidthInput, setShowSaddleWidthInput] = useState(false);
  const [distanceToCenterText, setDistanceToCenterText] = useState('');
  const [distanceSheetVisible, setDistanceSheetVisible] = useState(false);
  const [bendAngle, setBendAngle] = useState<Saddle4Angle>(SADDLE4_CONFIG.defaultAngle);
  const [setupVisible, setSetupVisible] = useState(false);
  const [angleSheetVisible, setAngleSheetVisible] = useState(false);

  const { setup, setSetup } = useCalculatorSetup();
  const { unit, rounding, conduitType, conduitSize, benderProfileId, customBenderProfiles } = setup;

  const benderProfile = getBenderProfile(benderProfileId, customBenderProfiles);
  const angleData = getSaddle4AngleData(bendAngle);
  const obstructionHeight = parseLengthInput(obstructionHeightText);
  const saddleWidth = parseLengthInput(saddleWidthText);
  const distanceToCenter = parseLengthInput(distanceToCenterText);
  const hasDistance = distanceToCenter !== undefined;
  const unitLabel = getLengthUnitLabel(unit);
  const setupSummary = `${conduitType} ${conduitSize}"`;
  const setupSubtitle = `${getUnitSystemLabel(unit)} • ${getRoundingLabel(rounding)}`;
  const hasValidHeight = obstructionHeight !== undefined && obstructionHeight > 0;
  const hasValidWidth = saddleWidth !== undefined && saddleWidth > 0;
  const hasValidInputs = hasValidHeight;
  const profileContextMessage = saddle4Copy.profileContext(angleData.label);
  const lengthInput = getLengthInputMode(unit);

  const result = useMemo(
    () =>
      calculateSaddle4({
        obstructionHeight: obstructionHeight ?? Number.NaN,
        saddleWidth: hasValidWidth ? saddleWidth : undefined,
        distanceToCenter: hasDistance ? distanceToCenter : undefined,
        bendAngle,
        benderProfileId,
        conduitType,
        tradeSize: conduitSize,
        unitSystem: unit,
        roundingPrecision: rounding,
        customBenderProfiles,
      }),
    [
      bendAngle,
      benderProfileId,
      conduitSize,
      conduitType,
      customBenderProfiles,
      distanceToCenter,
      hasDistance,
      obstructionHeight,
      rounding,
      saddleWidth,
      hasValidWidth,
      unit,
    ],
  );

  const centerMarkValue = hasValidInputs
    ? hasDistance
      ? result.centerMarkFormatted ?? '—'
      : saddle4Copy.results.centerMarkOptional
    : '—';

  const betweenBendsValue = hasValidInputs ? result.betweenBendsFormatted : '—';
  const shrinkValue = hasValidInputs ? result.shrinkFormatted : '—';

  // Field workflow: once a distance is entered, the Center Mark is the first
  // thing the user marks, so it becomes the hero. Otherwise the always-known
  // Between Bends spacing leads.
  const showCenterAsHero = hasValidInputs && hasDistance;
  const primaryLabel = showCenterAsHero
    ? saddle4Copy.results.centerMark
    : saddle4Copy.results.betweenBends;
  const primaryValue = showCenterAsHero ? centerMarkValue : betweenBendsValue;

  const secondaryResults = hasValidInputs
    ? showCenterAsHero
      ? [
          { label: saddle4Copy.results.betweenBends, value: betweenBendsValue },
          { label: saddle4Copy.results.shrink, value: shrinkValue },
        ]
      : [{ label: saddle4Copy.results.shrink, value: shrinkValue }]
    : undefined;

  const inputsStarted = obstructionHeightText.trim() !== '';
  const visibleWarnings = inputsStarted ? result.warnings : [];

  function handleBackPress() {
    const safeRouter = router as typeof router & { canGoBack?: () => boolean };

    if (typeof safeRouter.canGoBack === 'function' && safeRouter.canGoBack()) {
      router.back();
      return;
    }

    router.replace(Routes.home);
  }

  function applySetup(nextSetup: SetupValues) {
    setSetup(
      patchCalculatorSetup(setup, {
        conduitType: DEFAULT_CONDUIT_TYPE,
        conduitSize: nextSetup.conduitSize,
        benderProfileId: nextSetup.benderProfileId,
        unit: nextSetup.unit,
        rounding: nextSetup.rounding,
      }),
    );
    setSetupVisible(false);
  }

  function selectAngleByLabel(label: string) {
    const match = SADDLE4_CONFIG.validAngles.find(
      (angle) => SADDLE4_ANGLE_DATA[angle].label === label,
    );
    if (match) setBendAngle(match);
  }

  function resetInputs() {
    setObstructionHeightText('');
    setSaddleWidthText('');
    setShowSaddleWidthInput(false);
    setDistanceToCenterText('');
    setDistanceSheetVisible(false);
  }

  return (
    <BendCalculatorLayout
      title={saddle4Copy.screenTitle}
      subtitle={setupSummary}
      onBackPress={handleBackPress}
      trust={{
        benderName: benderProfile.name,
        meta: setupSubtitle,
        note: profileContextMessage,
        onEdit: () => setSetupVisible(true),
      }}
      inputs={[
        {
          type: 'row',
          key: 'height',
          inputs: [
            {
              type: 'field',
              key: 'obstructionHeight',
              label: saddle4Copy.fields.obstructionHeight.label,
              value: obstructionHeightText,
              onChangeText: setObstructionHeightText,
              placeholder: saddle4Copy.fields.obstructionHeight.placeholder,
              unit: unitLabel,
              variant: 'compact',
              lengthInput,
              error:
                obstructionHeightText !== '' && !hasValidHeight
                  ? saddle4Copy.fields.obstructionHeight.errorRequired
                  : undefined,
            },
          ],
        },
        {
          type: 'optional',
          key: 'saddleWidth',
          addLabel: saddle4Copy.fields.saddleWidth.addButton,
          onAdd: () => setShowSaddleWidthInput(true),
          visible: showSaddleWidthInput,
          field: {
            type: 'field',
            key: 'saddleWidthField',
            label: saddle4Copy.fields.saddleWidth.label,
            value: saddleWidthText,
            onChangeText: setSaddleWidthText,
            placeholder: saddle4Copy.fields.saddleWidth.placeholder,
            unit: unitLabel,
            variant: 'compact',
            lengthInput,
            error:
              saddleWidthText !== '' && !hasValidWidth
                ? saddle4Copy.fields.saddleWidth.errorRequired
                : undefined,
          },
        },
        {
          type: 'picker',
          key: 'angle',
          label: saddle4Copy.fields.bendAngle.label,
          value: angleData.label,
          onPress: () => setAngleSheetVisible(true),
        },
        ...(distanceToCenterText.trim()
          ? [
              {
                type: 'custom' as const,
                key: 'distanceSummary',
                node: (
                  <OptionalInputSummary
                    label={saddle4Copy.fields.distanceToCenter.label}
                    value={distanceToCenterText}
                    unit={unitLabel}
                    onPress={() => setDistanceSheetVisible(true)}
                  />
                ),
              },
            ]
          : []),
      ]}
      workspace={
        <Saddle4Diagram
          data={result.diagramData}
          isEmpty={!hasValidInputs}
          isInvalid={obstructionHeightText !== '' && !hasValidHeight}
        />
      }
      primaryResult={
        hasValidInputs ? { label: primaryLabel, value: primaryValue } : undefined
      }
      secondaryResults={secondaryResults}
      dock={{
        left: [
          { key: 'reset', label: 'Reset', onPress: resetInputs },
          { key: 'set-center', label: 'Set Center', onPress: () => setDistanceSheetVisible(true) },
        ],
        guide: { onPress: () => router.push(guideRoute('saddle4')) },
      }}
      warnings={visibleWarnings}
      footer={
        <>
          <LengthInputSheet
            visible={distanceSheetVisible}
            label={saddle4Copy.fields.distanceToCenter.label}
            value={distanceToCenterText}
            unit={unitLabel}
            placeholder={saddle4Copy.fields.distanceToCenter.placeholder}
            onCommit={(text) => {
              setDistanceToCenterText(text);
              setDistanceSheetVisible(false);
            }}
            onCancel={() => setDistanceSheetVisible(false)}
          />
          <Sheet
            visible={angleSheetVisible}
            title={saddle4Copy.angleSheetTitle}
            subtitle={saddle4Copy.angleSheetSubtitle}
            onClose={() => setAngleSheetVisible(false)}
            onSecondaryPress={() => setAngleSheetVisible(false)}
            primaryLabel="Done"
            onPrimaryPress={() => setAngleSheetVisible(false)}>
            <OptionChipGroup
              title={saddle4Copy.fields.bendAngle.label}
              options={ANGLE_LABELS}
              selected={angleData.label}
              onSelect={selectAngleByLabel}
            />
          </Sheet>
          <EditSetupSheet
            visible={setupVisible}
            values={{
              conduitType,
              conduitSize,
              benderProfileId,
              unit,
              rounding,
              bendAngle: 45,
            }}
            onCancel={() => setSetupVisible(false)}
            onApply={applySetup}
          />
        </>
      }
    />
  );
}
