import { useRouter } from 'expo-router';
import { useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import type { Href } from 'expo-router';

import { BEND_FAMILIES, type BendLibraryItem } from '@/data/bendLibrary';
import { Routes } from '@/navigation';
import {
  AppHeader,
  BottomNav,
  HubEmptyState,
  HubListGroup,
  HubListRow,
  HubSearchField,
  HubSectionTitle,
  Sheet,
  type BendTabId,
} from '@/shared/ui';
import { colors, uiTheme } from '@/theme';

const ACTIVE_ROUTES: Record<string, Href> = {
  'Basic Offset': Routes.offset,
  'Stub-Up 90': Routes.stub90,
  '3-Point Saddle': Routes.saddle3,
  '4-Point Saddle': Routes.saddle4,
  'Segment Bend': Routes.segment,
  'Rolling Offset': Routes.rolling,
};

export function BendsScreen() {
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [comingSoonVisible, setComingSoonVisible] = useState(false);

  const filteredFamilies = useMemo(() => {
    const normalized = search.trim().toLowerCase();

    if (!normalized) {
      return BEND_FAMILIES;
    }

    return BEND_FAMILIES.map((family) => ({
      ...family,
      items: family.items.filter((item) =>
        `${family.title} ${item.title} ${item.description ?? ''}`.toLowerCase().includes(normalized),
      ),
    })).filter((family) => family.items.length > 0);
  }, [search]);

  function handleTabChange(tab: BendTabId) {
    if (tab === 'layout') router.push(Routes.home);
    if (tab === 'bends') router.push(Routes.bends);
    if (tab === 'benders') router.push(Routes.benderDatabase);
    if (tab === 'guide') router.push(Routes.guide);
  }

  function handleBendPress(item: BendLibraryItem) {
    const route = ACTIVE_ROUTES[item.title];
    if (item.status === 'active' && route) {
      router.push(route);
      return;
    }
    setComingSoonVisible(true);
  }

  return (
    <View style={styles.screen}>
      <AppHeader
        title="Bends"
        subtitle="Choose a conduit layout"
        rightIcon={<Text style={styles.topIcon}>⚙</Text>}
        onRightPress={() => router.push(Routes.settings)}
      />

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled">
        <HubSearchField
          value={search}
          onChangeText={setSearch}
          placeholder="Search bend type"
        />

        {filteredFamilies.map((family) => (
          <View key={family.title} style={styles.familySection}>
            <HubSectionTitle>{family.title}</HubSectionTitle>
            <HubListGroup>
              {family.items.map((item, index) => (
                <HubListRow
                  key={item.title}
                  title={item.title}
                  description={item.description}
                  badge={item.status === 'coming-soon' ? 'Coming Soon' : undefined}
                  active={item.status === 'active'}
                  dimmed={item.status !== 'active'}
                  isLast={index === family.items.length - 1}
                  onPress={() => handleBendPress(item)}
                />
              ))}
            </HubListGroup>
          </View>
        ))}

        {filteredFamilies.length === 0 ? (
          <HubEmptyState title="No bend types found." body="Try a different search term." />
        ) : null}
      </ScrollView>

      <BottomNav activeTab="bends" onTabChange={handleTabChange} />

      <Sheet
        visible={comingSoonVisible}
        title="Coming Soon"
        subtitle="This bend type is not available yet."
        secondaryLabel="Close"
        onSecondaryPress={() => setComingSoonVisible(false)}
        onClose={() => setComingSoonVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    width: '100%',
    maxWidth: uiTheme.layout.maxContentWidth,
    alignSelf: 'center',
    padding: uiTheme.layout.screenPadding,
    paddingBottom: uiTheme.layout.sectionBottom,
    gap: uiTheme.hub.contentGap,
  },
  topIcon: {
    color: colors.text,
    fontSize: 20,
  },
  familySection: {
    gap: uiTheme.hub.sectionGap,
  },
});
